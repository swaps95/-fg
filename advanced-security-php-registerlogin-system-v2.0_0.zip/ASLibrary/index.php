<?php
header("Location: as/index.php");
?>
