<?php 

return array(

	//login, register and password reset

	"email" => "Email",

	"login" => "Login",

	"username" => "Username",

	"password" => "Password",

	"your_email" => "Your Email",

	"login_with" => "Login With",

	"email_confirmed" => "Email confirmed",

	"create_account" => "Create Account",

	"forgot_password" => "Forgot Password?",

	"repeat_password" => "Repeat Password",

	"reset_password" => "Reset Password",

	"email_confirmation" => "Email Confirmation",

	"you_can_loging_now" => "You can <a href='{link}'>log in</a> now.",

	"user_with_key_doesnt_exist" => "User with this key doesn't exist in our database.",


	// navigation menu

	"home" => "Home",

	"users" => "Users",

	"my_profile" => "My Profile",

	"user_roles" => "User Roles",


	// index.php

	"comment" => "Comment",

	"last_7_posts" => "last 7 posts",

	"comments_wall" => "Comments Wall",

	"leave_comment" => "Leave comment",

	"you_cant_post" => "You can't post comments here until admin change your role.",


	// profile.php

	"phone" => "Phone",

    "note" => "Note",

	"update" => "Update",

	"address" => "Address",

	"first_name" => "First Name",

	"last_name" => "Last Name",

	"old_password" => "Old Password",

	"new_password" => "New Password",

	"your_details" => "Your Details",

	"change_password" => "Change Password",

	"confirm_new_password" => "Confirm New Password",

    "to_change_email_username" => "If you want to change your username, email or you have registred via social network and you want to change your password now, please contact administrator.",

	// passwordreset.php

	"password_reset" => "Password Reset",

	"reset_password" => "Reset Password",


	// user_roles.php

	"add" => "Add",

	"action" => "Action",

	"role_name" => "Role Name",

	"users_with_role" => "# of users with this role",


	// users.php

	"ok" => "Ok",

	"ban" => "Ban",

	"yes" => "Yes",

	"no"  => "No",

    "edit" => "Edit",

    "next" => "Next",

    "previous" => "Previous",

	"unban" => "Unban",

	"cancel" => "Cancel",

	"delete" => "Delete",

	"details" => "Details",

	"loading" => "Loading...",

	"register_date" => "Register Date",
	
	"last_login" => "Last Login",

	"confirmed" => "Confirmed",

	"select_role" => "Select Role",

	"change_role" => "Change Role",

	"add_user"	  => "Add User",

	"pick_user_role" => "Pick User Role",

    "never_logged_in" => "Never logged in",

    // users table

    "records_per_page" => "records per page",

    "nothing_found"    => "Nothing found - sorry",

    "no_data_in_table" => "No users in database",

    "showing" => "Showing",

    "to" => "to",

    "of" => "of",

    "records" => "records",

    "filtered_from" => "filtered from",

    "total_records" => "total records",

    "search" => "Search",


	// misc

	"at" => "at",

	"logout" => "Logout",

	"welcome" => "Welcome",

	"copyright_by" => "Copyright by",


	// validation messages

	"user_banned" => "This user account is banned by administrator!",

	"field_required" => "Field cannot be empty!",

	"role_taken" => "Role already exist.",

	"email_required" => "Email is required.",

	"email_wrong_format" => "Please enter valid email.",

	"email_not_exist" => "This email doesn't exist in our database.",

	"email_taken" => "User with this email is already registred.",

	"username_required" => "Username is required.",

	"username_taken" => "Username already in use.",

	"user_not_confirmed" => "Please confirm your email first.",

	"password_required" => "Password is required.",

	"wrong_username_password" => "Wrong username/password combination.",

	"passwords_dont_match" => "Passwords don't match.",

	"wrong_old_password" => "Wrong old password!",

	"wrong_sum" => "Wrong sum. Please check it again.",

	"brute_force" => "You exceeded maximum attempts limit for today. Try again tomorrow.",

	"success_registration_with_confirm" =>  "Registration successful. Please check your email.",

	"success_registration_no_confirm" => "Registration successful. You can log in now.",

	"user_added_successfully" => "User added successfully.",

	"user_updated_successfully" => "User updated successfully.",

    "user_dont_exist" => "This user doesn't exist.",

    "leave_blank" => "Leave blank if you don't want to change it.",

    "invalid_password_reset_key" => "Password reset key is invalid or expired",

    "password_length" => "Password must be at least 6 characters long.",

    "error_writing_to_db" => "Error writing to database. Please try again.",

	// javascript

	"posting" => "Posting...",

	"logging_in" => "Loging in...",

	"resetting" => "Resetting...",

	"password_updated_successfully" => "Password successfully updated.",

	"password_updated_successfully_login" => "Password successfully updated. You can <a href='login.php'>login now</a>.",

	"working" => "Working...",

	"password_reset_email_sent" => "Password reset email sent. Check your inbox (and spam) folder.",

	"message_couldn_be_sent" => "Message could not be sent! Please try again.",

	"updating" => "Updating...",

	"details_updated" => "Details updated successfully.",

	"error_updating_db" => "Error while updating database. Please try again.",

	"are_you_sure" => "Are you sure?",

	"creating_account" => "Creating acount...",


);
