 </div>
        <div class="push"><!--//--></div>
    </div> <!-- end #wrap -->
    
    <footer class="footer">
      <div class="container">
       <p><?php echo ASLang::get('copyright_by'); ?> &copy; <?php echo WEBSITE_NAME . " " . date("Y"); ?></p>
      </div>
    </footer>