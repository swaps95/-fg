<p>Thank you for registering on {{website_name}}</p>

<p>Please confirm your email by clicking on the link below:</p>

<a href="{{link}}">Confirm Email</a> <br/><br/>

<p>If you can't click on that link, just copy and paste following url in your browser's address bar:</p>

<p>{{link}}</p>

Many Thanks, <br/>
{{website_name}}